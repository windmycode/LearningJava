package com.oracle.team.service;

public enum Status {
    FREE, BUSY, VOCATION
}
