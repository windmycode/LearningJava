package com.oracle.team.domain;

public interface Equipment {
    public String getDescription();
}
